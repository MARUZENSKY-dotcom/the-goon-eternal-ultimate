# GOON ETERNAL

Static game. index.html must be at the ROOT of the repo (a copy is also in /public).

Vercel: Framework Preset = Other, leave Build/Output/Install empty, Root Directory = ./
